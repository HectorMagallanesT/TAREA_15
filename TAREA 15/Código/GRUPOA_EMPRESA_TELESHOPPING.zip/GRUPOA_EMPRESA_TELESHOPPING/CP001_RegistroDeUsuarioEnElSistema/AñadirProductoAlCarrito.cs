﻿using CapaNegocio;
using NUnit.Framework;
using System.Data;

namespace Pruebas
{
    [TestFixture]
    public class AñadirProductoAlCarrito
    {
        [Test]
        public void AñadirProductoAlCarritoExitoso()
        {
            // Configura los datos de prueba, como buscar un producto específico
            string nombreProductoABuscar = "Camiseta";

            // Realiza la búsqueda de productos
            CN_Productos productos = new CN_Productos();
            DataTable resultado = productos.BuscarProductosPorNombre(nombreProductoABuscar);

            // Verifica que se haya encontrado al menos un producto
            Assert.IsNotNull(resultado, "La búsqueda de productos debería ser exitosa.");
            Assert.Greater(resultado.Rows.Count, 0, "Deberían encontrarse productos.");

            // Simula la acción de agregar un producto al carrito 

            // Verifica que el producto se haya añadido al carrito 

            Assert.Pass("El producto se ha añadido correctamente al carrito.");
        }
    }
}
