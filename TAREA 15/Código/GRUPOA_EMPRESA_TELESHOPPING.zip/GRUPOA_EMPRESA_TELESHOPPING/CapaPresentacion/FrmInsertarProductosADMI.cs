﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class FrmInsertarProductosADMI : Form
    {
        private string rutaImagen;
        CN_Productos negocioProductos = new CN_Productos();

        /// <summary>
        /// Constructor de la clase `FrmInsertarProductosADMI`.
        /// </summary>
        public FrmInsertarProductosADMI()
        {
            InitializeComponent();
            dgvProductos.DataSource = negocioProductos.GetListaProductos();

        }

        /// <summary>
        /// Maneja el evento Click del botón "Guardar".
        /// Valida los campos del formulario y guarda un nuevo producto en la base de datos.
        /// </summary>
        private void btnGuardar_Click_1(object sender, EventArgs e)
        {
            if (ValidarCampos())
            {
                // Obtén los valores de los campos del formulario
                string nombre = txtNombre.Text;
                string descripcion = txtDescripcion.Text;
                decimal precio = decimal.Parse(txtPrecio.Text);

                // Verifica si se ha seleccionado una imagen válida
                if (string.IsNullOrEmpty(rutaImagen) || !File.Exists(rutaImagen))
                {
                    MessageBox.Show("Debe seleccionar una imagen válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Convierte la imagen en bytes
                byte[] foto;
                try
                {
                    using (FileStream fs = new FileStream(rutaImagen, FileMode.Open, FileAccess.Read))
                    {
                        foto = new byte[fs.Length];
                        fs.Read(foto, 0, (int)fs.Length);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al convertir la imagen en un arreglo de bytes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Llama al método de la capa de negocio para insertar el producto
                bool exito = negocioProductos.InsertarProducto(foto, nombre, descripcion, precio);

                if (exito)
                {
                    MessageBox.Show("Producto insertado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Limpia los controles de entrada y la imagen después de la inserción
                    txtNombre.Text = "";
                    txtDescripcion.Text = "";
                    txtPrecio.Text = "";
                    ptFoto.Image = null;
                    rutaImagen = "";

                    // Actualiza el DataGridView con los nuevos datos si es necesario
                    ActualizarDataGridView();
                }
                else
                {
                    MessageBox.Show("Error al insertar el producto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        /// <summary>
        /// Actualiza el DataGridView con la lista de productos.
        /// </summary>
        public void ActualizarDataGridView()
        {
            dgvProductos.DataSource = negocioProductos.GetListaProductos();

        }

        /// <summary>
        /// Maneja el evento Click del botón "Foto".
        /// Abre un cuadro de diálogo para seleccionar una imagen y la muestra en el PictureBox.
        /// </summary>
        private void btnFoto_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Archivos de imagen|*.jpg;*.jpeg;*.png;*.gif;*.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                rutaImagen = openFileDialog.FileName;
                ptFoto.Image = Image.FromFile(rutaImagen);
            }
        }



        /// <summary>
        /// Maneja el evento Click del botón "Modificar".
        /// Modifica un producto seleccionado en la base de datos.
        /// </summary>
        private void btnModificar_Click(object sender, EventArgs e)
        {

            int productoID = ObtenerIDProductoSeleccionado();

            if (productoID > 0)
            {
                // Comprobar si se ha seleccionado una imagen nueva
                byte[] foto = null; // Esto inicializa la foto como nula, lo que significa que no se actualizará si sigue siendo nula

                if (!string.IsNullOrEmpty(rutaImagen) && File.Exists(rutaImagen))
                {
                    // Si se ha seleccionado una imagen válida, la convertimos en bytes
                    try
                    {
                        using (FileStream fs = new FileStream(rutaImagen, FileMode.Open, FileAccess.Read))
                        {
                            foto = new byte[fs.Length];
                            fs.Read(foto, 0, (int)fs.Length);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al convertir la imagen en un arreglo de bytes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                string nombre = txtNombre.Text; // Obtén el nombre del campo de texto
                string descripcion = txtDescripcion.Text; // Obtén la descripción del campo de texto
                decimal precio = decimal.Parse(txtPrecio.Text); // Obtén el precio del campo de texto

                bool exito = negocioProductos.ModificarProducto(productoID, foto, nombre, descripcion, precio);

                if (exito)
                {
                    MessageBox.Show("Producto modificado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ActualizarDataGridView();
                }
                else
                {
                    MessageBox.Show("Error al modificar el producto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        /// <summary>
        /// Obtiene el ID del producto seleccionado en el DataGridView.
        /// </summary>
        /// <returns>ID del producto seleccionado o -1 si no se ha seleccionado ningún producto.</returns>

        private int ObtenerIDProductoSeleccionado()
        {
            if (dgvProductos.SelectedRows.Count > 0)
            {
                // Obtén el valor de la celda de la columna "ID" de la fila seleccionada
                DataGridViewRow selectedRow = dgvProductos.SelectedRows[0];
                int productoID = Convert.ToInt32(selectedRow.Cells["ID"].Value);

                return productoID;
            }

            // Si no se selecciona ninguna fila, devuelve un valor por defecto, por ejemplo, -1
            return -1;
        }


        /// <summary>
        /// Maneja el evento Click del botón "Eliminar".
        /// Elimina un producto seleccionado de la base de datos.
        /// </summary>
        private void btnEliminar_Click_1(object sender, EventArgs e)
        {
        int productoID = ObtenerIDProductoSeleccionado();

            if (productoID != -1)
            {
                // Mostrar un cuadro de diálogo de confirmación
                DialogResult confirmResult = MessageBox.Show("¿Estás seguro de que deseas eliminar este producto?", "Confirmar Eliminación", MessageBoxButtons.YesNo);

                if (confirmResult == DialogResult.Yes)
                {
                    // Llama al método de la capa de negocio para eliminar el producto
                    bool exito = negocioProductos.EliminarProducto(productoID);

                    if (exito)
                    {
                        // Producto eliminado con éxito
                        MessageBox.Show("Producto eliminado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Actualiza el DataGridView después de la eliminación
                        ActualizarDataGridView();
                    }
                    else
                    {
                        MessageBox.Show("Error al eliminar el producto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un producto para eliminar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        /// Muestra una imagen en el PictureBox.
        /// </summary>
        private void MostrarImagenEnPictureBox(byte[] foto)
        {
            if (foto != null && foto.Length > 0)
            {
                using (MemoryStream ms = new MemoryStream(foto))
                {
                    ptFoto.Image = Image.FromStream(ms);
                }
            }
            else
            {
                ptFoto.Image = null;
            }
        }

        /// <summary>
        /// Valida los campos del formulario.
        /// </summary>
        /// <returns>True si los campos son válidos, de lo contrario, False.</returns>
        private bool ValidarCampos()
        {
            bool bandera = true;
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                // Mostrar el mensaje de error en el ErrorProvider
                errorProvider1.SetError(txtNombre, "El campo no puede estar vacío.");
                bandera = false;
            }
            else
            {
                // Limpiar el mensaje de error si el TextBox no está vacío
                errorProvider1.Clear();
            }




            if (string.IsNullOrWhiteSpace(txtDescripcion.Text))
            {
                // Mostrar el mensaje de error en el ErrorProvider
                errorProvider1.SetError(txtDescripcion, "El campo no puede estar vacío.");
                bandera = false;

            }
            else
            {
                // Limpiar el mensaje de error si el TextBox no está vacío
                errorProvider1.Clear();
            }



            if (string.IsNullOrWhiteSpace(txtPrecio.Text))
            {
                // Mostrar el mensaje de error en el ErrorProvider
                errorProvider1.SetError(txtPrecio, "El campo no puede estar vacío.");
                bandera = false;

            }
            else
            {
                // Limpiar el mensaje de error si el TextBox no está vacío
                errorProvider1.Clear();
            }

            return bandera;

        }

        /// <summary>
        /// Maneja el evento de cambio de selección en el DataGridView dgvProductos.
        /// Actualiza los campos de entrada (nombre, descripción, precio) y muestra la imagen en el PictureBox.
        /// </summary>
        /// <param name="sender">El objeto que desencadenó el evento.</param>
        /// <param name="e">Los datos del evento.</param>
        private void dgvProductos_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count > 0)
            {
                // Obtén la fila seleccionada
                DataGridViewRow selectedRow = dgvProductos.SelectedRows[0];

                // Obtén los valores de las celdas y colócalos en los controles
                txtNombre.Text = selectedRow.Cells["Nombre"].Value.ToString();
                txtDescripcion.Text = selectedRow.Cells["Descripcion"].Value.ToString();
                txtPrecio.Text = selectedRow.Cells["Precio"].Value.ToString();

                // También muestra la imagen, si tienes la columna "Foto" en el DataGridView
                if (dgvProductos.Columns.Contains("Foto"))
                {
                    byte[] foto = (byte[])selectedRow.Cells["Foto"].Value;
                    MostrarImagenEnPictureBox(foto);
                }
            }

        }



        /// <summary>
        /// Maneja el evento KeyPress del campo de texto de precio.
        /// Verifica si el carácter ingresado es un dígito numérico.
        /// </summary>
        private void txtPrecio_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verifica si el carácter ingresado no es un dígito numérico ni un carácter de control
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Ignora el carácter
                MessageBox.Show("Solo se permiten números.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Maneja el evento KeyPress del campo de texto de nombre.
        /// Verifica si el carácter ingresado es una letra o un espacio.
        /// </summary>
        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {

            // Verifica si el carácter ingresado no es una letra ni un espacio
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true; // Ignora el carácter
                MessageBox.Show("Solo se permiten letras.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

       
    }
}
