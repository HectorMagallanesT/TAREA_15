﻿namespace CapaPresentacion
{
    partial class FrmServicioAlCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Consud = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtInconveniente = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.btnEnviarAyuda = new System.Windows.Forms.Button();
            this.labelInformacionAdicional = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCorreoAyuda = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txtOtro = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.btnEnviarDC = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbCambioOd = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDetalleDC = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtValidar = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label16 = new System.Windows.Forms.Label();
            this.btnPago = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbPagos = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtDetallePago = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtValidarPagoc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.AccessibleName = "";
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(20, 77);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(761, 402);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.Consud);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.txtCorreo);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtInconveniente);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(753, 373);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Presentación de quejas";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // Consud
            // 
            this.Consud.AutoSize = true;
            this.Consud.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Consud.Location = new System.Drawing.Point(23, 24);
            this.Consud.Name = "Consud";
            this.Consud.Size = new System.Drawing.Size(124, 16);
            this.Consud.TabIndex = 6;
            this.Consud.Text = "Consulta general";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(164, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Correo electronico:";
            // 
            // txtCorreo
            // 
            this.txtCorreo.Location = new System.Drawing.Point(299, 49);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(203, 22);
            this.txtCorreo.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 322);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(327, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Servicio al cliente se comunicara con usted via correo";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(326, 258);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Enviar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Escriba su incoveniente:";
            // 
            // txtInconveniente
            // 
            this.txtInconveniente.Location = new System.Drawing.Point(52, 149);
            this.txtInconveniente.Multiline = true;
            this.txtInconveniente.Name = "txtInconveniente";
            this.txtInconveniente.Size = new System.Drawing.Size(633, 79);
            this.txtInconveniente.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.btnEnviarAyuda);
            this.tabPage2.Controls.Add(this.labelInformacionAdicional);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.txtCorreoAyuda);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Controls.Add(this.txtOtro);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(753, 373);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Solicitud de ayuda";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(124, 16);
            this.label11.TabIndex = 11;
            this.label11.Text = "Consulta general";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(447, 201);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(263, 23);
            this.button3.TabIndex = 10;
            this.button3.Text = "Manual de Usuario";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // btnEnviarAyuda
            // 
            this.btnEnviarAyuda.Location = new System.Drawing.Point(544, 277);
            this.btnEnviarAyuda.Name = "btnEnviarAyuda";
            this.btnEnviarAyuda.Size = new System.Drawing.Size(75, 23);
            this.btnEnviarAyuda.TabIndex = 9;
            this.btnEnviarAyuda.Text = "Enviar";
            this.btnEnviarAyuda.UseVisualStyleBackColor = true;
            this.btnEnviarAyuda.Click += new System.EventHandler(this.btnEnviarAyuda_Click);
            // 
            // labelInformacionAdicional
            // 
            this.labelInformacionAdicional.Location = new System.Drawing.Point(429, 72);
            this.labelInformacionAdicional.Multiline = true;
            this.labelInformacionAdicional.Name = "labelInformacionAdicional";
            this.labelInformacionAdicional.Size = new System.Drawing.Size(290, 111);
            this.labelInformacionAdicional.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(60, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "Correo electronico:";
            // 
            // txtCorreoAyuda
            // 
            this.txtCorreoAyuda.Location = new System.Drawing.Point(203, 30);
            this.txtCorreoAyuda.Name = "txtCorreoAyuda";
            this.txtCorreoAyuda.Size = new System.Drawing.Size(203, 22);
            this.txtCorreoAyuda.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(61, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 16);
            this.label5.TabIndex = 3;
            this.label5.Text = "Mas detallado su caso:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "¿Cómo puedo registrarme o crear una cuenta?",
            "¿Cómo restablezco mi contraseña si la olvido?",
            "¿Cómo hago un seguimiento de mis pedidos?",
            "¿Cuáles son los métodos de pago aceptados?",
            "¿Dónde puedo encontrar documentación adicional o recursos de ayuda?",
            "Otro"});
            this.comboBox1.Location = new System.Drawing.Point(64, 125);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(342, 24);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged_1);
            // 
            // txtOtro
            // 
            this.txtOtro.Location = new System.Drawing.Point(63, 258);
            this.txtOtro.Multiline = true;
            this.txtOtro.Name = "txtOtro";
            this.txtOtro.Size = new System.Drawing.Size(414, 58);
            this.txtOtro.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(61, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(182, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "¿En que se le puede ayudar?";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.btnEnviarDC);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.cmbCambioOd);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.txtDetalleDC);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.txtValidar);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(753, 373);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Devoluciones o cambios";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(38, 19);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(136, 16);
            this.label15.TabIndex = 15;
            this.label15.Text = "Consulta particular";
            // 
            // btnEnviarDC
            // 
            this.btnEnviarDC.Location = new System.Drawing.Point(347, 329);
            this.btnEnviarDC.Name = "btnEnviarDC";
            this.btnEnviarDC.Size = new System.Drawing.Size(75, 23);
            this.btnEnviarDC.TabIndex = 14;
            this.btnEnviarDC.Text = "Enviar";
            this.btnEnviarDC.UseVisualStyleBackColor = true;
            this.btnEnviarDC.Click += new System.EventHandler(this.btnEnviarDC_Click_1);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(55, 99);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 16);
            this.label10.TabIndex = 13;
            this.label10.Text = "Tipo de servicio:";
            // 
            // cmbCambioOd
            // 
            this.cmbCambioOd.FormattingEnabled = true;
            this.cmbCambioOd.Items.AddRange(new object[] {
            "Servicio de Devolucion",
            "Servicio de Cambio"});
            this.cmbCambioOd.Location = new System.Drawing.Point(186, 96);
            this.cmbCambioOd.Name = "cmbCambioOd";
            this.cmbCambioOd.Size = new System.Drawing.Size(236, 24);
            this.cmbCambioOd.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(55, 143);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(139, 16);
            this.label9.TabIndex = 10;
            this.label9.Text = "Detalle correctamente";
            // 
            // txtDetalleDC
            // 
            this.txtDetalleDC.Location = new System.Drawing.Point(58, 178);
            this.txtDetalleDC.Multiline = true;
            this.txtDetalleDC.Name = "txtDetalleDC";
            this.txtDetalleDC.Size = new System.Drawing.Size(652, 132);
            this.txtDetalleDC.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(183, 49);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(164, 16);
            this.label8.TabIndex = 9;
            this.label8.Text = "Validar correo electronico:";
            // 
            // txtValidar
            // 
            this.txtValidar.Location = new System.Drawing.Point(369, 46);
            this.txtValidar.Name = "txtValidar";
            this.txtValidar.Size = new System.Drawing.Size(203, 22);
            this.txtValidar.TabIndex = 8;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Controls.Add(this.btnPago);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.cmbPagos);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.txtDetallePago);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Controls.Add(this.txtValidarPagoc);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(753, 373);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Problemas de pago";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(26, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(136, 16);
            this.label16.TabIndex = 20;
            this.label16.Text = "Consulta particular";
            // 
            // btnPago
            // 
            this.btnPago.Location = new System.Drawing.Point(338, 328);
            this.btnPago.Name = "btnPago";
            this.btnPago.Size = new System.Drawing.Size(75, 23);
            this.btnPago.TabIndex = 19;
            this.btnPago.Text = "Enviar";
            this.btnPago.UseVisualStyleBackColor = true;
            this.btnPago.Click += new System.EventHandler(this.btnPago_Click_1);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(46, 98);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(161, 16);
            this.label13.TabIndex = 18;
            this.label13.Text = "Tipo de pago que realizo:";
            // 
            // cmbPagos
            // 
            this.cmbPagos.FormattingEnabled = true;
            this.cmbPagos.Items.AddRange(new object[] {
            "Tarjeta de crédito",
            "Paypal",
            "Transferencia Bancaria",
            "Efectivo"});
            this.cmbPagos.Location = new System.Drawing.Point(213, 95);
            this.cmbPagos.Name = "cmbPagos";
            this.cmbPagos.Size = new System.Drawing.Size(236, 24);
            this.cmbPagos.TabIndex = 17;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(46, 143);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(139, 16);
            this.label14.TabIndex = 16;
            this.label14.Text = "Detalle correctamente";
            // 
            // txtDetallePago
            // 
            this.txtDetallePago.Location = new System.Drawing.Point(49, 177);
            this.txtDetallePago.Multiline = true;
            this.txtDetallePago.Name = "txtDetallePago";
            this.txtDetallePago.Size = new System.Drawing.Size(652, 132);
            this.txtDetallePago.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(176, 44);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(164, 16);
            this.label12.TabIndex = 11;
            this.label12.Text = "Validar correo electronico:";
            // 
            // txtValidarPagoc
            // 
            this.txtValidarPagoc.Location = new System.Drawing.Point(362, 41);
            this.txtValidarPagoc.Name = "txtValidarPagoc";
            this.txtValidarPagoc.Size = new System.Drawing.Size(203, 22);
            this.txtValidarPagoc.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(346, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Servicio al cliente";
            // 
            // FrmServicioAlCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 503);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Name = "FrmServicioAlCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Servicio al cliente";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label Consud;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtInconveniente;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnEnviarAyuda;
        private System.Windows.Forms.TextBox labelInformacionAdicional;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCorreoAyuda;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox txtOtro;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnEnviarDC;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbCambioOd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDetalleDC;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtValidar;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnPago;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmbPagos;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtDetallePago;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtValidarPagoc;
        private System.Windows.Forms.Label label1;
    }
}