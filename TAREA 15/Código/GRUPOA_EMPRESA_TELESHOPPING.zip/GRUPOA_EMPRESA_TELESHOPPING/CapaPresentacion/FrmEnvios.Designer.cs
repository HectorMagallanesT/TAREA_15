﻿namespace CapaPresentacion
{
    partial class FrmEnvios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnEnviar = new System.Windows.Forms.Button();
            this.txtDescripcionCompra = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbTransporte = new System.Windows.Forms.ComboBox();
            this.dtpFechaEnvio = new System.Windows.Forms.DateTimePicker();
            this.txtDestinatario = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCIEnvio = new System.Windows.Forms.TextBox();
            this.txtSeguimiento = new System.Windows.Forms.TextBox();
            this.txtValorCompra = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnEnviar
            // 
            this.BtnEnviar.BackColor = System.Drawing.Color.LightSeaGreen;
            this.BtnEnviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEnviar.Location = new System.Drawing.Point(828, 447);
            this.BtnEnviar.Margin = new System.Windows.Forms.Padding(4);
            this.BtnEnviar.Name = "BtnEnviar";
            this.BtnEnviar.Size = new System.Drawing.Size(116, 53);
            this.BtnEnviar.TabIndex = 43;
            this.BtnEnviar.Text = "Enviar";
            this.BtnEnviar.UseVisualStyleBackColor = false;
            this.BtnEnviar.Click += new System.EventHandler(this.BtnEnviar_Click);
            // 
            // txtDescripcionCompra
            // 
            this.txtDescripcionCompra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDescripcionCompra.Location = new System.Drawing.Point(624, 186);
            this.txtDescripcionCompra.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescripcionCompra.Multiline = true;
            this.txtDescripcionCompra.Name = "txtDescripcionCompra";
            this.txtDescripcionCompra.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtDescripcionCompra.Size = new System.Drawing.Size(314, 220);
            this.txtDescripcionCompra.TabIndex = 42;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(675, 149);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(183, 18);
            this.label7.TabIndex = 41;
            this.label7.Text = "Descripcion de compra";
            // 
            // cmbTransporte
            // 
            this.cmbTransporte.FormattingEnabled = true;
            this.cmbTransporte.Items.AddRange(new object[] {
            "UPS",
            "SERVIENTREGA",
            "LAARCOURRIER",
            "DHL"});
            this.cmbTransporte.Location = new System.Drawing.Point(296, 347);
            this.cmbTransporte.Margin = new System.Windows.Forms.Padding(4);
            this.cmbTransporte.Name = "cmbTransporte";
            this.cmbTransporte.Size = new System.Drawing.Size(265, 24);
            this.cmbTransporte.TabIndex = 40;
            // 
            // dtpFechaEnvio
            // 
            this.dtpFechaEnvio.Enabled = false;
            this.dtpFechaEnvio.Location = new System.Drawing.Point(296, 298);
            this.dtpFechaEnvio.Margin = new System.Windows.Forms.Padding(4);
            this.dtpFechaEnvio.Name = "dtpFechaEnvio";
            this.dtpFechaEnvio.Size = new System.Drawing.Size(265, 22);
            this.dtpFechaEnvio.TabIndex = 39;
            // 
            // txtDestinatario
            // 
            this.txtDestinatario.Enabled = false;
            this.txtDestinatario.Location = new System.Drawing.Point(296, 248);
            this.txtDestinatario.Margin = new System.Windows.Forms.Padding(4);
            this.txtDestinatario.Name = "txtDestinatario";
            this.txtDestinatario.Size = new System.Drawing.Size(265, 22);
            this.txtDestinatario.TabIndex = 36;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(104, 404);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 18);
            this.label6.TabIndex = 35;
            this.label6.Text = "Valor de compra";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(104, 348);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 18);
            this.label5.TabIndex = 34;
            this.label5.Text = "Transportista";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(104, 303);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 18);
            this.label4.TabIndex = 33;
            this.label4.Text = "Fecha de envio";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(100, 162);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 18);
            this.label3.TabIndex = 32;
            this.label3.Text = "# de Seguimiento";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(100, 249);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 18);
            this.label2.TabIndex = 31;
            this.label2.Text = "Nombre Destinatario";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label1.Location = new System.Drawing.Point(356, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(332, 41);
            this.label1.TabIndex = 30;
            this.label1.Text = "LOGISTICA DE ENVIO";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(100, 205);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 18);
            this.label9.TabIndex = 45;
            this.label9.Text = "CI";
            // 
            // txtCIEnvio
            // 
            this.txtCIEnvio.Location = new System.Drawing.Point(296, 201);
            this.txtCIEnvio.Margin = new System.Windows.Forms.Padding(4);
            this.txtCIEnvio.Name = "txtCIEnvio";
            this.txtCIEnvio.Size = new System.Drawing.Size(265, 22);
            this.txtCIEnvio.TabIndex = 46;
            this.txtCIEnvio.TextChanged += new System.EventHandler(this.txtCIEnvio_TextChanged);
            // 
            // txtSeguimiento
            // 
            this.txtSeguimiento.Enabled = false;
            this.txtSeguimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeguimiento.Location = new System.Drawing.Point(296, 158);
            this.txtSeguimiento.Margin = new System.Windows.Forms.Padding(4);
            this.txtSeguimiento.Name = "txtSeguimiento";
            this.txtSeguimiento.Size = new System.Drawing.Size(265, 28);
            this.txtSeguimiento.TabIndex = 47;
            // 
            // txtValorCompra
            // 
            this.txtValorCompra.Enabled = false;
            this.txtValorCompra.Location = new System.Drawing.Point(296, 403);
            this.txtValorCompra.Name = "txtValorCompra";
            this.txtValorCompra.Size = new System.Drawing.Size(265, 22);
            this.txtValorCompra.TabIndex = 49;
            // 
            // FrmEnvios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1041, 543);
            this.Controls.Add(this.txtValorCompra);
            this.Controls.Add(this.txtSeguimiento);
            this.Controls.Add(this.txtCIEnvio);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.BtnEnviar);
            this.Controls.Add(this.txtDescripcionCompra);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbTransporte);
            this.Controls.Add(this.dtpFechaEnvio);
            this.Controls.Add(this.txtDestinatario);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FrmEnvios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Envios";
            this.Load += new System.EventHandler(this.FrmEnvios_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BtnEnviar;
        private System.Windows.Forms.TextBox txtDescripcionCompra;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbTransporte;
        private System.Windows.Forms.DateTimePicker dtpFechaEnvio;
        private System.Windows.Forms.TextBox txtDestinatario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCIEnvio;
        private System.Windows.Forms.TextBox txtSeguimiento;
        private System.Windows.Forms.TextBox txtValorCompra;
    }
}