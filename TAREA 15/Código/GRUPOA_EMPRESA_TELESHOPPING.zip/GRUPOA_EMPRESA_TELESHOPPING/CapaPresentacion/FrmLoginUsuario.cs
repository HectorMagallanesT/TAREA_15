﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Authentication;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using CapaException;


namespace CapaPresentacion
{
    public partial class FrmLoginUsuario : Form
    {
        // Declaración de la clase LoginUsuarioN
        private LoginUsuarioN loginUsuarioN;

        private UsuarioDatos usuarioDatos;


        // Variable estática para almacenar el CI del usuario para su uso en otros formularios
        public static string CiValor { get; private set; }

        public FrmLoginUsuario()
        {
            InitializeComponent();

            // Cadena de conexión a la base de datos
            string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";

            // Inicialización de una instancia de la clase LoginUsuarioN
            loginUsuarioN = new LoginUsuarioN(connectionString);

            usuarioDatos = new UsuarioDatos(connectionString);

        }


        /// <summary>
        /// Evento que se activa al hacer clic en el botón "Acceder".
        /// Verifica el usuario y la contraseña ingresados para iniciar sesión.
        /// </summary>
        private void btnAcceder_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores ingresados en los TextBox
                string ci = txtCILogin.Text;
                string contrasena = txtContrasenaLogin.Text;

                // Asignar el valor de `ci` a la variable estática `CiValue`
                CiValor = ci;

                // Verificar si los campos están vacíos
                if (string.IsNullOrEmpty(ci) || string.IsNullOrEmpty(contrasena))
                {
                    throw new AccesoException("Por favor, complete todos los campos");
                }

                // Verificar si el usuario existe en la base de datos
                bool usuarioExiste = loginUsuarioN.VerificarUsuario(ci, contrasena);

                if (usuarioExiste)
                {
                    ci = txtCILogin.Text; // Obtener el CI ingresado en el primer formulario

                    // Abrir el FrmModulos y pasar el CI como parámetro al constructor
                    FrmModulos frmModulos = new FrmModulos(ci);
                    frmModulos.Show();
                    this.Hide(); // Ocultar el formulario actual

                    // Limpiar los TextBox de inicio de sesión
                    txtCILogin.Text = "";
                    txtContrasenaLogin.Text = "";
                }
                else
                {
                    throw new AccesoException("El CI o la contraseña ingresada son incorrectos. Por favor, verifique sus datos o regístrese.");
                }
            }
            catch (AccesoException ex)
            {
                // Manejar la excepción y mostrar un mensaje de error personalizado
                MessageBox.Show(ex.Message, "Error de acceso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        /// <summary>
        /// Evento que se activa al hacer clic en el botón "Crear Usuario".
        /// Crea un nuevo usuario en la base de datos.
        /// </summary>
        private void btnCrearUsuario_Click(object sender, EventArgs e)
        {
            try
            {
                // Recopilar los valores de los TextBox en variables
                string nombreYApellido = txtNombreCuenta.Text;
                string ci = txtCI.Text;
                string email = txtEmail.Text;
                string contrasena = txtContrasena.Text;
                string confirmarContrasena = txtConfirmarContrasena.Text;

                // Verificar si algún TextBox está vacío
                if (string.IsNullOrEmpty(nombreYApellido) || string.IsNullOrEmpty(ci) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(contrasena) || string.IsNullOrEmpty(confirmarContrasena))
                {
                    MessageBox.Show("Por favor, complete todos los datos antes de registrarse", "CAMPOS INCOMPLETOS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Validar que el campo CI contenga solo números y tenga una longitud de 10 caracteres
                if (!Regex.IsMatch(ci, "^[0-9]{10}$"))
                {
                    MessageBox.Show("Ingrese un CI válido que conste de 10 dígitos", "REVISE CI", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Verificar si el usuario ya existe en la base de datos
                if (loginUsuarioN.ExisteUsuario(ci))
                {
                    LimpiarTextBox();
                    MessageBox.Show("El usuario ya existe", "USUARIO EXISTENTE", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Validar que las contrasenas coincidan
                if (contrasena != confirmarContrasena)
                {
                    MessageBox.Show("La contraseña y la confirmación de contraseña deben coincidir", "VERIFICAR", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Validar la contraseña requerida
                if (!ValidarContrasena(contrasena))
                {
                    throw new CrearUsuarioException("La contraseña no cumple con los requisitos establecidos");
                }

                // Crear un nuevo usuario en la base de datos
                loginUsuarioN.CrearUsuario(nombreYApellido, ci, email, contrasena, confirmarContrasena);

                MessageBox.Show("Usuario creado con éxito", "BIENVENIDO", MessageBoxButtons.OK);
                LimpiarTextBox();
            }
            catch (CrearUsuarioException ex)
            {
                // Manejar la excepción y mostrar un mensaje de error personalizado
                MessageBox.Show(ex.Message, "Error al crear usuario", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        /// <summary>
        /// Evento que se activa al hacer clic en el enlace "Contraseña Olvidada".
        /// Abre el formulario de recuperación de contraseña.
        /// </summary>
        private void linkLblContraseñaOlvidada_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            // Declaración e inicialización de una instancia de la clase FrmRecordarContrasena
            FrmRecordarContrasena recordarContrasena = new FrmRecordarContrasena();

            // Mostrar el formulario FrmRecordarContrasena en pantalla
            recordarContrasena.Show();
        }
     
        /// <summary>
        /// Valida que una contraseña cumpla con los requisitos establecidos.
        /// </summary>
        /// <param name="contraseña">Contraseña a validar.</param>
        /// <returns>True si la contraseña cumple con los requisitos, False en caso contrario.</returns>
        private bool ValidarContrasena(string contraseña)
        {
            // Expresión regular para validar la contraseña
            string patron = "^(?=.*[A-Z])(?=.*[a-z]{2})(?=.*[0-9]{2}).{8,}$";

            // Verificar si la contraseña coincide con el patrón
            return Regex.IsMatch(contraseña, patron);
        }


        /// <summary>
        /// Limpia los TextBox de registro de usuario.
        /// </summary>
        private void LimpiarTextBox()
        {
            txtNombreCuenta.Text = "";
            txtCI.Text = "";
            txtEmail.Text = "";
            txtContrasena.Text = "";
            txtConfirmarContrasena.Text = "";
        }

        /// <summary>
        /// Limpia los TextBox de actualizar datos
        /// </summary>
        private void LimpiarTextBoxActualizar()
        {
            txtActualizarNYA.Text = "";
            txtBuscarCI.Text = "";
            txtActualizarEmail.Text = "";
            txtActualizarContrasena.Text = "";
            txtActualizarConfirmarContrasena.Text = "";
        }


        /// <summary>
        /// Limpia los TextBox de txtADMIN / txtADMINContrsena
        /// </summary>
        private void LimpiarTextBoxAdmin()
        {
            txtADMINCI.Text = "";
            txtADMINContrasena.Text = "";
        }

        /// <summary>
        /// Evento que se activa al hacer clic en el botón "Buscar".
        /// Busca un usuario por su CI y muestra los datos para su actualización.
        /// </summary>
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string ci = txtBuscarCI.Text;
            Usuario usuario = usuarioDatos.BuscarUsuarioPorCI(ci);

            if (usuario != null)
            {
                txtActualizarNYA.Text = usuario.NombreYApellido;
                txtActualizarEmail.Text = usuario.Email;
                txtActualizarContrasena.Text = usuario.Contrasena;
                txtActualizarConfirmarContrasena.Text = usuario.ConfirmarContrasena;
            }
            else
            {
                MessageBox.Show("No existe en el sistema, registrese");
                LimpiarTextBoxActualizar();
            }
        }

        /// <summary>
        /// Evento que se activa al hacer clic en el botón "Actualizar".
        /// Actualiza los datos del usuario en la base de datos.
        /// </summary>
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            Usuario usuario = new Usuario
            {
                CI = txtBuscarCI.Text,
                NombreYApellido = txtActualizarNYA.Text,
                Email = txtActualizarEmail.Text,
                Contrasena = txtActualizarContrasena.Text,
                ConfirmarContrasena = txtActualizarConfirmarContrasena.Text
            };

            bool actualizacionExitosa = usuarioDatos.ActualizarUsuario(usuario);


            // Recopilar los valores de los TextBox en variables
            string nombreYApellido = txtActualizarNYA.Text;
            string ci = txtBuscarCI.Text;
            string email = txtActualizarEmail.Text;
            string contrasena = txtActualizarContrasena.Text;
            string confirmarContrasena = txtActualizarConfirmarContrasena.Text;

            // Verificar si algún TextBox está vacío
            if (string.IsNullOrEmpty(nombreYApellido) || string.IsNullOrEmpty(ci) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(contrasena) || string.IsNullOrEmpty(confirmarContrasena))
            {
                MessageBox.Show("Por favor, complete todos los datos antes de actualizarlos", "CAMPOS INCOMPLETOS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Validar que el campo CI contenga solo números y tenga una longitud de 10 caracteres
            if (!Regex.IsMatch(ci, "^[0-9]{10}$"))
            {
                MessageBox.Show("Ingrese un CI válido que conste de 10 dígitos", "REVISE CI", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que las contraseñas coincidan
            if (contrasena != confirmarContrasena)
            {
                MessageBox.Show("La contraseña y la confirmación de contraseña deben coincidir", "VERIFICAR", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar la contraseña requerida
            if (!ValidarContrasena(contrasena))
            {
                MessageBox.Show("La contraseña no cumple con los requisitos establecidos", "VERIFICAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (actualizacionExitosa)
            {
                MessageBox.Show("Usuario actualizado con éxito", "USUARIO ACTUALIZADO", MessageBoxButtons.OK);
                LimpiarTextBoxActualizar();

            }
            else
            {
                MessageBox.Show("Error al actualizar los datos.");
                LimpiarTextBoxActualizar(); 
            }

        }

        /// <summary>
        /// Evento que se activa al hacer clic en el botón "Acceder como Administrador".
        /// Autentica al usuario con privilegios de administrador.
        /// </summary>
        private void btnAccederADMIN_Click(object sender, EventArgs e)
        {
            AutenticarUsuario();
        }

        /// <summary>
        /// Autentica al usuario con privilegios de administrador.
        /// </summary>
        private void AutenticarUsuario()
        {
            try
            {
                // Obtener los valores de los campos de texto
                string ci = txtADMINCI.Text;
                string contrasena = txtADMINContrasena.Text;

                // Verificar si los valores son correctos
                if (ci != "0950167823" || contrasena != "0950167823")
                {
                    // Lanza la excepción si la autenticación falla
                    throw new AutenticacionException("CI o contraseña incorrectos. Por favor, verifique los datos e intente de nuevo.");
                }

                // Si los valores son correctos, abrir el formulario FrmInsertarProductosADMI
                FrmADMIN frmAdmin = new FrmADMIN();
                frmAdmin.Show();
                LimpiarTextBoxAdmin();
            }
            catch (AutenticacionException ex)
            {
                // Manejar la excepción y mostrar un mensaje de error personalizado
                MessageBox.Show(ex.Message, "Error de autenticación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LimpiarTextBoxAdmin();
            }
        }

        /// <summary>
        /// Evento que se activa cuando se hace clic en el enlace "Eliminar Cuenta".
        /// </summary>
        /// <param name="sender">El control que generó el evento.</param>
        /// <param name="e">Los datos del evento.</param>
        private void linkLabelEliminarCuenta_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Obtener el valor del número de cédula desde el txtCILogin
            string ciToDelete = txtCILogin.Text;

            // Llamar a la función de eliminación de usuario en tu capa de datos
            bool eliminacionExitosa = usuarioDatos.EliminarUsuarioPorCI(ciToDelete);

            if (eliminacionExitosa)
            {
                MessageBox.Show("Usuario eliminado con éxito.", "Eliminación Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Limpia los TextBox de inicio de sesión después de una eliminación exitosa.
                txtCILogin.Text = "";
                txtContrasenaLogin.Text = "";
            }
            else
            {
                MessageBox.Show("No se pudo eliminar el usuario. Verifica tus datos.", "Error en la Eliminación", MessageBoxButtons.OK, MessageBoxIcon.Error);

                // Limpia los TextBox de inicio de sesión después de una eliminación exitosa.
                txtCILogin.Text = "";
                txtContrasenaLogin.Text = "";

            }
        }
    }
}

