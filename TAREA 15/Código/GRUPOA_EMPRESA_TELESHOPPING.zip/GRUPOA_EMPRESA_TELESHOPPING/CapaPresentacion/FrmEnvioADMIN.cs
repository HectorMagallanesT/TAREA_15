﻿using CapaNegocio;
using System;
using System.Data;
using System.Windows.Forms;

namespace CapaPresentacion
{
    /// <summary>
    /// Clase parcial que representa el formulario para la administración de envíos por parte de un usuario con rol de administrador.
    /// </summary>
    public partial class FrmEnvioADMIN : Form
    {
        private EnvioADMIN_N envioADMIN_N;

        /// <summary>
        /// Constructor de la clase FrmEnvioADMIN.
        /// </summary>
        public FrmEnvioADMIN()
        {
            InitializeComponent();

            // Inicializa la instancia de la capa de negocio para envíos de administrador
            envioADMIN_N = new EnvioADMIN_N();
        }

        /// <summary>
        /// Manejador de eventos que se ejecuta al cargar el formulario FrmEnvioADMIN.
        /// </summary>
        private void FrmEnvioADMIN_Load_1(object sender, EventArgs e)
        {
            // Llama al método CargarDatosEnDataGridView al cargar el formulario
            CargarDatosEnDataGridView();
        }

        /// <summary>
        /// Método privado que carga los datos de envíos en el DataGridView.
        /// </summary>
        private void CargarDatosEnDataGridView()
        {
            try
            {
                // Utiliza la capa de negocio para obtener los datos de envíos
                DataTable dataTable = envioADMIN_N.ObtenerDatosEnvio();

                // Asigna el DataTable como DataSource del DataGridView
                dgvLogistica.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                // Muestra un mensaje de error en caso de excepción
                MessageBox.Show("Error al cargar datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
