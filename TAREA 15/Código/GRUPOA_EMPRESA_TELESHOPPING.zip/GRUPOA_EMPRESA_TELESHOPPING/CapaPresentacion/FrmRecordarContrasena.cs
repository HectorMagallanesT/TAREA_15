﻿
using CapaNegocio;
using System;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class FrmRecordarContrasena : Form
    {
        // Declarar una instancia de la clase RecordarContrasenaN
        private RecordarContrasenaN negocio;


        /// <summary>
        /// Constructor del formulario FrmRecordarContrasena.
        /// Inicializa los componentes del formulario y crea una nueva instancia de la clase RecordarContrasenaN.
        /// </summary>
        public FrmRecordarContrasena()
        {
            InitializeComponent();

            // Crear una nueva instancia de la clase RecordarContrasenaN
            negocio = new RecordarContrasenaN();
        }


        /// <summary>
        /// Evento del botón "Buscar" que llama al método para buscar el usuario.
        /// </summary>
        private void btnMostrar_Click(object sender, EventArgs e){
        // Llamar al método para buscar el usuario
        BuscarUsuario();
        }


        /// <summary>
        /// Método para buscar el usuario por medio del CI ingresado en el textBoxIngresoCI.
        /// </summary>
        private void BuscarUsuario()
        {
            // Obtener el valor ingresado en el textBoxIngresoCI y eliminar los espacios en blanco
            string ci = txtIngresarCI.Text.Trim();

            if (!EsNumero(ci) || ci.Length != 10)
            {
                // Mostrar un MessageBox donde el CI debe contener 10 dígitos numéricos
                MessageBox.Show("El CI debe contener 10 dígitos numéricos", "VERIFICAR CI", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Llamar al método BuscarContrasena de la instancia de la clase RecordarContrasenaN
            // y guardar el resultado en la variable contrasena
            string contrasena = negocio.BuscarContrasena(ci);

            // Verificar si la contraseña no es nula o vacía
            if (!string.IsNullOrEmpty(contrasena))
            {
                // Mostrar un MessageBox con la contraseña encontrada
                MessageBox.Show($"Su contraseña es: {contrasena}", "INFORMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Mostrar un MessageBox indicando que el usuario no está registrado en el sistema
                MessageBox.Show("No está registrado en el sistema", "VERIFICAR REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        /// Método para verificar si un texto está compuesto únicamente por caracteres numéricos.
        /// </summary>
        /// <param name="texto">Texto a verificar.</param>
        /// <returns>True si el texto contiene únicamente caracteres numéricos, False en caso contrario.</returns>
        private bool EsNumero(string texto)
        {
            // Recorrer cada carácter en el texto.
            foreach (char c in texto)
            {
                // Si se encuentra algún carácter no numérico, se retorna false.
                if (!char.IsDigit(c))
                {

                    // Si encontramos un carácter que no es un dígito numérico, retornamos false,
                    // indicando que la cadena no está compuesta únicamente por números.
                    return false;
                }
            }

            // Si todos los caracteres son numéricos, se retorna true.
            return true;
        }

    
    }
}
