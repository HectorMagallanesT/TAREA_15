﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaDatos;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class frmConsultaCatalogo : Form
    {
        CN_Productos negocioProdutcos = new CN_Productos();
        private string nombreYApellido;

        // Variable para acceder a la capa de datos usuarioD
        private ModulosD ModulosD;

        // Cadena de conexión a la base de datos
        private string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";

        /// <summary>
        /// Constructor de la clase `frmConsultaCatalogo` sin argumentos.
        /// </summary>
        public frmConsultaCatalogo()
        {
            InitializeComponent();
            MostrarProductos();
            btnAnadir.Visible = false;
        }

        /// <summary>
        /// Constructor de la clase `frmConsultaCatalogo` con nombre y apellido como argumento.
        /// </summary>
        /// <param name="nombreYApellido">Nombre y apellido del usuario.</param>
        public frmConsultaCatalogo(string nombreYApellido)
        {
            InitializeComponent();
            this.nombreYApellido = nombreYApellido;
            MostrarProductos();
        }

        /// <summary>
        /// Muestra los productos en el DataGridView.
        /// </summary>
        private void MostrarProductos()
        {
            CN_Productos negocioCandidatas = new CN_Productos();
            dgvProductos.DataSource = negocioCandidatas.GetListaProductos();
            // Establecer un alto ligeramente mayor para las filas
            dgvProductos.RowTemplate.Height = 120; // Ajusta el valor según tus preferencias

            // Ajustar el ancho de la columna de la foto para mostrarla completa
            dgvProductos.Columns["Foto"].Width = 200; // Ajusta el ancho a lo que consideres necesario

            // Ajustar el tamaño y estilo de las celdas de la columna de la foto
            dgvProductos.Columns["Foto"].DefaultCellStyle.Padding = new Padding(5); // Ajusta el espaciado interno de la celda
            dgvProductos.Columns["Foto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // Alineación centrada
        }

        /// <summary>
        /// Maneja el evento Click del botón de búsqueda.
        /// Realiza una búsqueda de productos por nombre.
        /// </summary>
        private void btnBuscar_Click_1(object sender, EventArgs e)
        {
            string nombreProductoABuscar = txtBuscar.Text.Trim();

            // Llama al método de la capa de negocio para buscar productos por nombre
            DataTable resultados = negocioProdutcos.BuscarProductosPorNombre(nombreProductoABuscar);

            // Verifica si se encontraron resultados
            if (resultados.Rows.Count > 0)
            {
                // Si se encontraron resultados, muestra los productos en el DataGridView
                dgvProductos.DataSource = resultados;
            }
            else
            {
                // Si no se encontraron resultados, muestra un mensaje de error o limpia el DataGridView
                dgvProductos.DataSource = null; // Limpia el DataGridView
                MessageBox.Show("No se encontraron productos con ese nombre.", "Búsqueda", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        /// Maneja el evento Click del botón "Añadir al carrito".
        /// Agrega un producto seleccionado al carrito de compras del usuario.
        /// </summary>
        private void btnAnadir_Click_1(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count > 0)
            {
                DataGridViewRow filaSeleccionada = dgvProductos.SelectedRows[0];
                int productoID = (int)filaSeleccionada.Cells["ID"].Value; // Asume que el nombre de la columna es "ID"

                if (!string.IsNullOrEmpty(nombreYApellido))
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    using (SqlCommand command = new SqlCommand("sp_AgregarAlCarrito", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@NombreUsuario", nombreYApellido); // Nombre del usuario
                        command.Parameters.AddWithValue("@ProductoID", productoID);

                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Añadido correctamente");
                    }
                }
                else
                {
                    MessageBox.Show("No se ha proporcionado un nombre de usuario.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("No se ha seleccionado ningún producto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Maneja el evento de cambio de selección en el DataGridView de productos.
        /// Muestra u oculta el botón "Añadir al carrito" según si hay una fila seleccionada.
        /// </summary>
        private void dgvProductos_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count > 0)
            {
                // Si hay al menos una fila seleccionada, muestra el botón "Añadir al carrito"
                btnAnadir.Visible = true;
            }
            else
            {
                // Si no hay filas seleccionadas, oculta el botón "Añadir al carrito"
                btnAnadir.Visible = false;
            }
        }

        /// <summary>
        /// Maneja el evento Click del botón "Carrito".
        /// Abre el formulario de carrito de compras.
        /// </summary>
        private void btnCarrito_Click_1(object sender, EventArgs e)
        {
            FrmCarritoA frmCarrito = new FrmCarritoA(nombreYApellido);
            frmCarrito.ShowDialog();
        }
    }
}








