﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using CapaDatos;
using CapaNegocio;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CapaPresentacion
{

    /// <summary>
    /// Clase que representa el formulario de Servicio al Cliente en la capa de presentación.
    /// </summary>
    public partial class FrmServicioAlCliente : Form
    {

        string correo;

        /// <summary>
        /// Constructor de la clase FrmServicioAlCliente.
        /// </summary>
        public FrmServicioAlCliente()
        {
            InitializeComponent();

        }

        private Panel panelInformacionAdicional;


        CN_ValidacionDatos usuarios = new CN_ValidacionDatos();

        /// <summary>
        /// Evento de clic en el botón de envío de quejas.
        /// </summary>
        private void button1_Click_1(object sender, EventArgs e)
        {
            // Dirección de correo electrónico de destino (correo de la empresa)
            string correoDestino = "teleshoppingserviciocliente@gmail.com";

            // Obtener la dirección de correo electrónico del remitente desde el TextBox
            string correoRemitente = txtCorreo.Text.Trim(); // Trim para eliminar espacios en blanco

            // Validar que se haya ingresado una dirección de correo electrónico
            if (string.IsNullOrWhiteSpace(correoRemitente) || !IsValidEmail(correoRemitente))
            {
                MessageBox.Show("Ingrese una dirección de correo electrónico válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Configuración del cliente SMTP
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential(correoDestino, "eagvdkudmbgnnrsn"),
                EnableSsl = true
            };

            // Crear el mensaje de correo
            MailMessage correo = new MailMessage()
            {
                From = new MailAddress(correoRemitente), // Dirección de correo electrónico del remitente
                Subject = "Presentacion de quejas:",
                Body = $"Correo del Cliente: {correoRemitente}\n\nInconveniente o Quejas:\n{txtInconveniente.Text}"
            };

            // Agregar destinatario (correo de la empresa)
            correo.To.Add(correoDestino);

            try
            {
                // Enviar el mensaje de correo
                smtpClient.Send(correo);
                MessageBox.Show("Correo enviado exitosamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al enviar el correo: {ex.ToString()}");
                MessageBox.Show($"Error al enviar el correo: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Liberar recursos
                correo.Dispose();
            }
        }


        /// <summary>
        /// Método para validar una dirección de correo electrónico.
        /// </summary>
        /// <param name="email">Dirección de correo electrónico a validar.</param>
        /// <returns>True si la dirección de correo es válida, de lo contrario, false.</returns>
        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email && !string.IsNullOrEmpty(addr.Address);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Maneja el evento de selección de ítem en el ComboBox.
        /// </summary>
        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Ocultar el TextBox por defecto
            txtOtro.Visible = false;

            // Obtener la pregunta seleccionada
            string preguntaSeleccionada = comboBox1.SelectedItem.ToString();

            // Mostrar información adicional según la pregunta seleccionada (puedes usar un Label u otro control)
            switch (preguntaSeleccionada)
            {
                case "¿Cómo puedo registrarme o crear una cuenta?":
                    MostrarInformacionAdicional("Para registrarse o crear una cuenta, deberá ingresar a la pestaña que sale al iniciar la aplicación, la cual tiene como nombre 'Registrarse'. Es necesario leer el manual de usuario, el cual se puede ver dando clic al boton 'Manual de usuario'");
                    break;

                case "¿Cómo restablezco mi contraseña si la olvido?":
                    MostrarInformacionAdicional("Para restablecer la contraseña, esta parte se encuentra en la pestaña 'Usuario' la cual dira en la parte de la venta '¿Olvido su contraseña?', esta abrira una nueva pestaña que para restablecer su contraseña debera ingresar su cedula.");
                    break;

                case "¿Cómo hago un seguimiento de mis pedidos?":
                    MostrarInformacionAdicional("Para realizar seguimiento de sus pedidos. Debera ingresar a la pestaña que se encuentra en la principal que se llama '");
                    break;


                case "¿Cuáles son los métodos de pago aceptados?":
                    MostrarInformacionAdicional("Los metodos de pagos son los siguientes: \\r\nTarjeta de crédito\r\nPaypal\r\nTransferencia Bancaria\r\nEfectivo");
                    break;

                case "¿Dónde puedo encontrar documentación adicional o recursos de ayuda?":
                    MostrarInformacionAdicional("Se encuentra el manual de usuario debajo del menu de opciones que ha seleccionado, Este se abrira en un archivo de intenet para que sea mas rapido al verlo.");
                    break;


                case "Otro":
                    // Si selecciona "Otro", mostrar el TextBox para que el usuario ingrese su propia pregunta
                    txtOtro.Visible = true;
                    txtCorreoAyuda.Visible = true;
                    btnEnviarAyuda.Visible = true;


                    LimpiarInformacionAdicional(); // Limpiar cualquier información adicional anterior
                    break;

                default:
                    // Limpiar o esconder la información adicional si no se selecciona ninguna pregunta específica
                    LimpiarInformacionAdicional();
                    break;
            }
        }

        /// <summary>
        /// Muestra información adicional en un control específico.
        /// </summary>
        private void MostrarInformacionAdicional(string informacion, string enlaceManual = null)
        {
            // Mostrar la información adicional en un control (puedes usar un Label u otro control)
            labelInformacionAdicional.Text = informacion;
            labelInformacionAdicional.Visible = true;

            // Ocultar el TextBox adicional si estaba visible
            txtOtro.Visible = false;


        }

        /// <summary>
        /// Limpia o esconde la información adicional.
        /// </summary>
        private void LimpiarInformacionAdicional()
        {
            // Limpiar o esconder la información adicional si no se selecciona ninguna pregunta específica
            labelInformacionAdicional.Text = "";
            labelInformacionAdicional.Visible = false;

        }

        /// <summary>
        /// Maneja el evento de clic en el botón para abrir el manual de usuario.
        /// </summary>
        private void button3_Click_1(object sender, EventArgs e)
        {
            // Reemplaza "URL_DEL_MANUAL_EN_DRIVE" con la URL real de tu archivo compartido en Google Drive
            string urlManualUsuario = "https://drive.google.com/file/d/1NgvszzxcM_D0g2iQGAKskgjvQhQ2Sw0x/view?usp=drive_link";

            // Abrir el navegador web predeterminado con la URL del manual de usuario
            try
            {
                Process.Start(urlManualUsuario);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al abrir el manual de usuario: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Maneja el evento de clic en el botón para enviar detalles de cambio u otros problemas.
        /// </summary>
        private void btnEnviarDC_Click_1(object sender, EventArgs e)
        {
            // Dirección de correo electrónico de destino (correo de la empresa)
            string correoDestino = "teleshoppingserviciocliente@gmail.com";

            // Obtener la dirección de correo electrónico del remitente desde el TextBox
            string correoRemitente = txtValidar.Text.Trim();

            // Validar que se haya ingresado una dirección de correo electrónico
            if (string.IsNullOrWhiteSpace(correoRemitente) || !IsValidEmail(correoRemitente))
            {
                MessageBox.Show("Ingrese una dirección de correo electrónico válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar que el correo electrónico exista en la base de datos
            if (!usuarios.VerificarExistenciaCorreoElectronico(txtValidar.Text))
            {
                MessageBox.Show("El correo electrónico no existe en la base de datos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Configuración del cliente SMTP
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential(correoDestino, "eagvdkudmbgnnrsn"),
                EnableSsl = true
            };

            // Crear el mensaje de correo
            MailMessage correo = new MailMessage()
            {
                From = new MailAddress(correoRemitente), // Dirección de correo electrónico del remitente
                Subject = "Problema de " + cmbCambioOd.Text,
                Body = $"Correo del Cliente: {correoRemitente}\n\nDetalle del problema:\n{txtDetalleDC.Text}"
            };

            // Agregar destinatario (correo de la empresa)
            correo.To.Add(correoDestino);

            try
            {
                // Enviar el mensaje de correo
                smtpClient.Send(correo);
                MessageBox.Show("Correo enviado exitosamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al enviar el correo: {ex.ToString()}");
                MessageBox.Show($"Error al enviar el correo: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Liberar recursos
                correo.Dispose();
            }
        }

        /// <summary>
        /// Maneja el evento de clic en el botón para enviar solicitudes de ayuda.
        /// </summary>
        private void btnEnviarAyuda_Click(object sender, EventArgs e)
        {
            // Dirección de correo electrónico de destino (correo de la empresa)
            string correoDestino = "teleshoppingserviciocliente@gmail.com";

            // Obtener la dirección de correo electrónico del remitente desde el TextBox
            string correoRemitente = txtCorreoAyuda.Text.Trim(); // Trim para eliminar espacios en blanco

            // Validar que se haya ingresado una dirección de correo electrónico
            if (string.IsNullOrWhiteSpace(correoRemitente) || !IsValidEmail(correoRemitente))
            {
                MessageBox.Show("Ingrese una dirección de correo electrónico válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Configuración del cliente SMTP
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential(correoDestino, "eagvdkudmbgnnrsn"),
                EnableSsl = true
            };

            // Crear el mensaje de correo
            MailMessage correo = new MailMessage()
            {
                From = new MailAddress(correoRemitente), // Dirección de correo electrónico del remitente
                Subject = "Soliccitud de Ayuda:",
                Body = $"Correo del Cliente: {correoRemitente}\n\nOtro caso de ayuda:\n{txtOtro.Text}"
            };

            // Agregar destinatario (correo de la empresa)
            correo.To.Add(correoDestino);

            try
            {
                // Enviar el mensaje de correo
                smtpClient.Send(correo);
                MessageBox.Show("Correo enviado exitosamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al enviar el correo: {ex.ToString()}");
                MessageBox.Show($"Error al enviar el correo: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Liberar recursos
                correo.Dispose();
            }

        }

        /// <summary>
        /// Maneja el evento de clic en el botón para enviar detalles de problemas de pago.
        /// </summary>
        private void btnPago_Click_1(object sender, EventArgs e)
        {
            // Dirección de correo electrónico de destino (correo de la empresa)
            string correoDestino = "teleshoppingserviciocliente@gmail.com";

            // Obtener la dirección de correo electrónico del remitente desde el TextBox
            string correoRemitente = txtValidarPagoc.Text.Trim();

            // Validar que se haya ingresado una dirección de correo electrónico
            if (string.IsNullOrWhiteSpace(correoRemitente) || !IsValidEmail(correoRemitente))
            {
                MessageBox.Show("Ingrese una dirección de correo electrónico válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar que el correo electrónico exista en la base de datos
            if (!usuarios.VerificarExistenciaCorreoElectronico(txtValidarPagoc.Text))
            {
                MessageBox.Show("El correo electrónico no existe en la base de datos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Configuración del cliente SMTP
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential(correoDestino, "eagvdkudmbgnnrsn"),
                EnableSsl = true
            };

            // Crear el mensaje de correo
            MailMessage correo = new MailMessage()
            {
                From = new MailAddress(correoRemitente), // Dirección de correo electrónico del remitente
                Subject = "Tipo de problema de pago: " + cmbPagos.Text,
                Body = $"Correo del Cliente: {correoRemitente}\n\nDetalle del problema - SECCION PAGOS:\n{txtDetallePago.Text}"
            };

            // Agregar destinatario (correo de la empresa)
            correo.To.Add(correoDestino);

            try
            {
                // Enviar el mensaje de correo
                smtpClient.Send(correo);
                MessageBox.Show("Correo enviado exitosamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al enviar el correo: {ex.ToString()}");
                MessageBox.Show($"Error al enviar el correo: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Liberar recursos
                correo.Dispose();
            }
        }

       
    }
}

