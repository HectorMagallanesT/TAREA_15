﻿using System;

namespace CapaException
{
    /// <summary>
    /// Excepción personalizada para manejar errores relacionados con el acceso a datos.
    /// </summary>
    public class AccesoException : Exception
    {
        /// <summary>
        /// Inicializa una nueva instancia de la clase AccesoException.
        /// </summary>
        public AccesoException() : base() { }

        /// <summary>
        /// Inicializa una nueva instancia de la clase AccesoException con un mensaje de error personalizado.
        /// </summary>
        /// <param name="message">Mensaje de error personalizado.</param>
        public AccesoException(string message) : base(message) { }

        /// <summary>
        /// Inicializa una nueva instancia de la clase AccesoException con un mensaje de error personalizado
        /// y una excepción interna que causó esta excepción.
        /// </summary>
        /// <param name="message">Mensaje de error personalizado.</param>
        /// <param name="innerException">Excepción interna que causó esta excepción.</param>
        public AccesoException(string message, Exception innerException) : base(message, innerException) { }
    }
}
