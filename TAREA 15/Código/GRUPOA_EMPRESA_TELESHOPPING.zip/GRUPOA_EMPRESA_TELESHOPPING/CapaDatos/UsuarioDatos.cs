﻿using System.Data.SqlClient;
using System;
using System.Data;
using CapaDatos;

/// <summary>
/// Clase que maneja la interacción con la base de datos para operaciones relacionadas con usuarios.
/// </summary>
public class UsuarioDatos
{
    private string connectionString;



    /// <summary>
    /// Constructor de la clase UsuarioDatos.
    /// </summary>
    /// <param name="connectionString">Cadena de conexión a la base de datos.</param>
    public UsuarioDatos(string connectionString)
    {
        this.connectionString = connectionString;
    }

    /// <summary>
    /// Busca un usuario por su número de cédula de identidad (CI) en la base de datos.
    /// </summary>
    /// <param name="ci">Número de cédula de identidad del usuario.</param>
    /// <returns>Un objeto Usuario si se encuentra, o null si no existe.</returns>
    public Usuario BuscarUsuarioPorCI(string ci)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            using (SqlCommand command = new SqlCommand("SELECT * FROM userDatos WHERE CI = @CI", connection))
            {
                command.Parameters.AddWithValue("@CI", ci);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Usuario
                        {
                            CI = reader["CI"].ToString(),
                            NombreYApellido = reader["nombreYApellido"].ToString(),
                            Email = reader["email"].ToString(),
                            Contrasena = reader["contrasena"].ToString(),
                            ConfirmarContrasena = reader["confirmarContrasena"].ToString()
                        };
                    }
                }
            }
        }

        return null; // El usuario no fue encontrado
    }


    /// <summary>
    /// Actualiza los datos de un usuario en la base de datos.
    /// </summary>
    /// <param name="usuario">Objeto Usuario con los datos actualizados.</param>
    /// <returns>true si la actualización fue exitosa; de lo contrario, false.</returns>
    public bool ActualizarUsuario(Usuario usuario)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            using (SqlCommand command = new SqlCommand("UPDATE userDatos SET nombreYApellido = @NombreYApellido, email = @Email, contrasena = @Contrasena, confirmarContrasena = @ConfirmarContrasena WHERE CI = @CI", connection))
            {
                command.Parameters.AddWithValue("@CI", usuario.CI);
                command.Parameters.AddWithValue("@NombreYApellido", usuario.NombreYApellido);
                command.Parameters.AddWithValue("@Email", usuario.Email);
                command.Parameters.AddWithValue("@Contrasena", usuario.Contrasena);
                command.Parameters.AddWithValue("@ConfirmarContrasena", usuario.ConfirmarContrasena);

                int rowsAffected = command.ExecuteNonQuery();
                return rowsAffected > 0; // Retorna true si se afectó al menos una fila, lo que indica una actualización exitosa
            }
        }
    }


    /// <summary>
    /// Busca un usuario por su número de cédula de identidad (CI) en el contexto de pagos.
    /// </summary>
    /// <param name="ci">Número de cédula de identidad del usuario.</param>
    /// <returns>Un objeto DataTable con los datos del usuario encontrado.</returns>
    public DataTable BuscarUsuarioPorCIPago(string ci)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            using (SqlCommand command = new SqlCommand("BuscarUsuarioPorCIPago", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ci", ci);
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    return dataTable;
                }
            }
        }
    }


    /// <summary>
    /// Elimina un usuario de la base de datos por su número de cédula (CI).
    /// </summary>
    /// <param name="ci">Número de cédula del usuario a eliminar.</param>
    /// <returns>True si la eliminación fue exitosa, de lo contrario, False.</returns>
    public bool EliminarUsuarioPorCI(string ci)
    {
        // Declarar una variable para verificar si la eliminación fue exitosa
        bool eliminacionExitosa = false;

        try
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Crear un comando para llamar al procedimiento almacenado
                using (SqlCommand command = new SqlCommand("EliminarUsuarioPorCI", connection))
                {
                    // Indicar que es un procedimiento almacenado
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar el parámetro @CI
                    command.Parameters.AddWithValue("@CI", ci);

                    // Ejecutar el comando y obtener el resultado
                    int result = (int)command.ExecuteScalar();

                    // Si result es 1, la eliminación fue exitosa
                    eliminacionExitosa = result == 1;
                }
            }
        }
        catch (Exception ex)
        {
            // Maneja cualquier excepción que pueda ocurrir durante la eliminación
            Console.WriteLine("Error al eliminar el usuario: " + ex.Message);
            eliminacionExitosa = false;
        }

        return eliminacionExitosa;
    }

}


