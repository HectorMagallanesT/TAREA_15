﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class CD_Logistica
    {
        private string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";

        /// <summary>
        /// Obtiene todos los envíos desde la base de datos.
        /// </summary>
        /// <returns>DataTable con los registros de envíos.</returns>
        public DataTable ObtenerEnvios()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("ObtenerEnvios", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    return dataTable;
                }
            }
        }

        /// <summary>
        /// Inserta un nuevo envío en la base de datos.
        /// </summary>
        public void InsertarEnvio(string seguimiento, string ci, string nombre, string fecha, string transportista, string valor, string descripcion)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("InsertarEnvio", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Seguimiento", seguimiento);
                    command.Parameters.AddWithValue("@CI", ci);
                    command.Parameters.AddWithValue("@Nombre", nombre);
                    command.Parameters.AddWithValue("@Fecha", fecha);
                    command.Parameters.AddWithValue("@Transportista", transportista);
                    command.Parameters.AddWithValue("@Valor", valor);
                    command.Parameters.AddWithValue("@Descripcion", descripcion);

                    command.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        /// Obtiene la cantidad de envíos en proceso para un usuario específico.
        /// </summary>
        public int ObtenerCantidadEnviosEnProceso(string ci)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("ObtenerCantidadEnviosEnProceso", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CI", ci);

                    return (int)command.ExecuteScalar();
                }
            }
        }

        /// <summary>
        /// Busca un pago por CI y devuelve el nombre y el total.
        /// </summary>
        public DataTable BuscarPagoPorCI(string ci)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("BuscarPagoPorCI", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CI", ci);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    return dataTable;
                }
            }
        }
    }
}
