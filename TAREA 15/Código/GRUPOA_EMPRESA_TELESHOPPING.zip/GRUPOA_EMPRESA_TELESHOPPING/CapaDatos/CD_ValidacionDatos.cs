﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    /// <summary>
    /// Clase que proporciona métodos para validar datos en la capa de datos.
    /// </summary>
    public class CD_ValidacionDatos
    {
        private CD_Connection conn = new CD_Connection();

        /// <summary>
        /// Verifica la existencia de un correo electrónico en la base de datos.
        /// </summary>
        /// <param name="correo">Dirección de correo electrónico a verificar.</param>
        /// <returns>True si el correo electrónico existe, false si no.</returns>
        public bool ExisteCorreoElectronico(string correo)
        {
            bool existe = false;

            using (SqlConnection connection = conn.GetConnection())
            {
                try
                {
                    string query = "VerificarExistenciaCorreoElectronico";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Parámetro de entrada
                        command.Parameters.AddWithValue("@correo", correo);

                        // Parámetro de salida
                        command.Parameters.Add("@existe", SqlDbType.Int);
                        command.Parameters["@existe"].Direction = ParameterDirection.Output;

                        connection.Open();
                        command.ExecuteNonQuery();

                        // Obtener el valor del parámetro de salida
                        existe = Convert.ToInt32(command.Parameters["@existe"].Value) == 1;
                    }
                }
                catch (Exception ex)
                {
                    // Manejar la excepción según tus necesidades
                    Console.WriteLine($"Error en la operación: {ex.Message}");
                }
            } // La conexión se cerrará automáticamente al salir del bloque using

            return existe;
        }

    }
}