﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    /// <summary>
    /// Clase que proporciona métodos de acceso a datos relacionados con la entidad "Envio" para administradores.
    /// </summary>
    public class EnvioADMIN_D
    {
        private string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";

        /// <summary>
        /// Obtiene los datos de todos los envíos.
        /// </summary>
        /// <returns>DataTable con los datos de los envíos.</returns>
        public DataTable ObtenerDatosEnvio()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Consulta SQL para seleccionar todos los registros de la tabla Envio
                    string query = "SELECT * FROM Envio";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        return dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                // Captura y relanza cualquier excepción ocurrida durante el proceso
                throw new Exception("Error al obtener datos de Envio: " + ex.Message);
            }
        }
    }
}
