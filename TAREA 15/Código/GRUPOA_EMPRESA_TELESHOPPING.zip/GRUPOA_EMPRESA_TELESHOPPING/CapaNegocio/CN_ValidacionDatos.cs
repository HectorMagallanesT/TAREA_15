﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class CN_ValidacionDatos
    {
        CD_ValidacionDatos validacionDatos = new CD_ValidacionDatos();

        /// <summary>
        /// Verifica la existencia de un correo electrónico en la base de datos.
        /// </summary>
        /// <param name="correo">Correo electrónico a verificar.</param>
        /// <returns>True si el correo electrónico existe, de lo contrario, false.</returns>
        public bool VerificarExistenciaCorreoElectronico(string correo)
        {
            return validacionDatos.ExisteCorreoElectronico(correo);
        }
    }
}
