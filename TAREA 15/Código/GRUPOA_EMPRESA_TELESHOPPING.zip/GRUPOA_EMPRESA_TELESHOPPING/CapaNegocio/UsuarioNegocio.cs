﻿using System;
using System.Data;
using CapaDatos;

namespace CapaNegocio
{
    /// <summary>
    /// Clase que maneja la lógica de negocios relacionada con los usuarios y los pagos.
    /// </summary>
    public class UsuarioNegocio
    {
        private UsuarioDatos usuarioDatos;
        private DatosAcceso datosAcceso;

        /// <summary>
        /// Constructor de la clase que recibe la cadena de conexión a la base de datos.
        /// </summary>
        /// <param name="connectionString">Cadena de conexión a la base de datos.</param>
        public UsuarioNegocio(string connectionString)
        {
            usuarioDatos = new UsuarioDatos(connectionString);
            datosAcceso = new DatosAcceso(connectionString);
        }

        /// <summary>
        /// Busca un usuario por su cédula de identidad y retorna un DataTable con los datos del usuario.
        /// </summary>
        /// <param name="ci">Cédula de identidad del usuario.</param>
        /// <returns>Un DataTable con los datos del usuario o una tabla vacía si no se encuentra.</returns>
        public DataTable BuscarUsuarioPorCI(string ci)
        {
            return datosAcceso.BuscarUsuarioPorCI(ci);
        }

        /// <summary>
        /// Realiza un pago y almacena la información relacionada en la base de datos.
        /// </summary>
        /// <param name="ci">Cédula de identidad del cliente.</param>
        /// <param name="nombreYApellido">Nombre y apellido del cliente.</param>
        /// <param name="email">Correo electrónico del cliente.</param>
        /// <param name="direccion">Dirección del cliente.</param>
        /// <param name="telefono">Número de teléfono del cliente.</param>
        /// <param name="metodoPago">Método de pago utilizado.</param>
        /// <param name="fechaHora">Fecha y hora de la transacción.</param>
        /// <param name="total">Monto total de la transacción.</param>
        public void RealizarPago(string ci, string nombreYApellido, string email, string direccion, string telefono, string metodoPago, DateTime fechaHora, decimal total)
        {
            datosAcceso.RealizarPago(ci, nombreYApellido, email, direccion, telefono, metodoPago, fechaHora, total);
        }

        /// <summary>
        /// Busca un usuario por su cédula de identidad y retorna un DataTable con los datos del usuario para el proceso de pago.
        /// </summary>
        /// <param name="ci">Cédula de identidad del usuario.</param>
        /// <returns>Un DataTable con los datos del usuario o una tabla vacía si no se encuentra.</returns>
        public DataTable BuscarUsuarioPorCIPago(string ci)
        {
            return usuarioDatos.BuscarUsuarioPorCIPago(ci);
        }

        /// <summary>
        /// Elimina los registros relacionados con el carrito de compras en la base de datos.
        /// </summary>
        public void EliminarRegistrosCarrito()
        {
            datosAcceso.EliminarRegistrosCarrito();
        }
    }
}
